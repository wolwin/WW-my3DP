Bezeichnungen;
==============

- HM-WM55_MOD-Rx-8_Body.stl
  - Homematic WM55 Basis-Modul für HM-MOD-Re-8 Modulplatine

- HM-WM55_MOD-Rx-8_BTN-4_LED-8.stl
  - Homematic WM55 Gehäuse-Modul für 4 Taster und 8 LEDs
- HM-WM55_MOD-Rx-8_BTN-4_LED-8_Label.stl
  - Homematic WM55 Gehäuse-Modul für 4 Taster und 8 LEDs mit Bezeichnung

- HM-WM55_MOD-Rx-8_BTN-8_LED-8.stl
  - Homematic WM55 Gehäuse-Modul für 8 Taster und 8 LEDs
- HM-WM55_MOD-Rx-8_BTN-8_LED-8_Label.stl
  - Homematic WM55 Gehäuse-Modul für 8 Taster und 8 LEDs mit Bezeichnung

- HM-WM55_MOD-Rx-8_LED-8.stl
  - Homematic WM55 Gehäuse-Modul für 8 LEDs
- HM-WM55_MOD-Rx-8_LED-8_Label.stl
  - Homematic WM55 Gehäuse-Modul für 8 LEDs mit Bezeichnung

- HM-WM55_MOD-Rx-8_Button.stl
  - Homematic WM55 Taster für Gehäuse-Modul
- HM-WM55_MOD-Rx-8_Button-4.stl
  - Homematic WM55 vier Taster für Gehäuse-Modul

- HM-WM55_MOD-Rx-8_Label.stl
  - Homematic WM55 Bezeichnungsabdeckung für Gehäuse-Modul


Notwendiges Material:
=====================

Batteriekontakt Plus für 55er Aufputzgehäuse, LR03
Artikel 098647
https://de.elv.com/batteriekontakt-plus-fuer-55er-aufputzgehaeuse-lr03-098647

Batteriekontakt Minus für 55er Aufputzgehäuse, LR03
Artikel 098648
https://de.elv.com/batteriekontakt-minus-fuer-55er-aufputzgehaeuse-lr03-098648
