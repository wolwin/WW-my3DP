Bezeichnungen;
==============

- HM-WM55-Body.stl
  - Homematic WM55 Basis-Modul

- HM-WM55-Body_HB-UNI-Mini-X.stl
  - Homematic WM55 Modul für HB-UNI-Mini-X Platine

- HM-WM55-Body_MOD-Rx-8.stl
  - Homematic WM55 Modul für 
    - HM-MOD-Re-8 Module
    - HM-MOD-EM-8 Module

- HM-WM55-Body_WM-x.stl
  - Homematic WM55 Module (z.B.: Homematic Funk-Wandtaster 2fach HM-PB-2-WM55-2) 


Notwendiges Material:
=====================

Batteriekontakt Plus für 55er Aufputzgehäuse, LR03
Artikel 098647
https://de.elv.com/batteriekontakt-plus-fuer-55er-aufputzgehaeuse-lr03-098647

Batteriekontakt Minus für 55er Aufputzgehäuse, LR03
Artikel 098648
https://de.elv.com/batteriekontakt-minus-fuer-55er-aufputzgehaeuse-lr03-098648
